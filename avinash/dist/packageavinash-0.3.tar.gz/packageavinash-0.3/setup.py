# from setuptools import setup
# setup(name="mymodule",version="0.1",description="sum of number ",long_description="the me be help to perform sum of two number",author="avinash",packages=["mymolude"],install_requires=[])
from setuptools import setup
setup(name='packageavinash',version='0.3',
description='ye avinash ka module hai',
Long_description='avinash sharm aji kese ho sob badhi ya hai na',author='avinash',
packages=['packageavinash'],
install_requires=[])