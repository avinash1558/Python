def funct(n):
    print('avinash sharma')
    return n